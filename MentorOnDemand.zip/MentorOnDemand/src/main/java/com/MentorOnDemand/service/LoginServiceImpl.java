package com.MentorOnDemand.service;

public class LoginServiceImpl implements LoginService{

}
