package com.MentorOnDemand.service;

public interface LoginService {

}
